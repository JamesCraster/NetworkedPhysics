var express = require("express");
var app = express();
var http = require('http').Server(app);
var io = require("socket.io")(http);

app.use(express.static('public'));

var Inputs = {
    LEFT: 'LEFT',
    RIGHT: 'RIGHT',
    DOWN: 'DOWN',
    UP: 'UP',
    NONE: 'NONE'
}

io.on("connection", function (socket) {
    let directions = [Inputs.NONE, Inputs.NONE];
    let player = {
        vx: 0,
        vy: 0,
        grounded: false
    };
    let position = {
        x: 0,
        y: 0
    };

    socket.on('input', function (direction) {
        if (direction == Inputs.LEFT || direction == Inputs.RIGHT) {
            directions[0] = direction;
        }
        if (direction == Inputs.UP || direction == Inputs.DOWN) {
            directions[1] = direction;
        }
    });

    function update() {
        if (directions[0] == Inputs.LEFT) {
            player.vx -= 4;
        } else if (directions[0] == Inputs.RIGHT) {
            player.vx += 4;
        }
        if (directions[1] == Inputs.UP) {
            console.log(player.grounded);
            if (player.grounded == true) {
                player.vy -= 50;
                player.grounded = false;
            }
            directions[1] = Inputs.NONE;
        }
        player.vy += 5;

        if (player.vx > 20) {
            player.vx = 20;
        }
        if (player.vx < -20) {
            player.vx = -20;
        }
        if (player.vy > 30) {
            player.vy = 30;
        }

        if (position.y + player.vy > 550) {
            position.y = 550;
            player.vy = 0;
            player.grounded = true;
        }
        if (position.x + player.vx < 0) {
            position.x = 0;
            player.vx = 0;
        }
        if (position.x + player.vx > 750) {
            position.x = 750;
            player.vx = 0;
        }
        position.x += player.vx;
        position.y += player.vy;
        socket.emit('update', position);
    }
    setInterval(update, 100);
});

function update() {

}

var port = 8081;
http.listen(port, function () {
    console.log('Port is:' + port);
});